// Shared utility functions

/**
 * @param {string} url
 * @returns {string}
 */
function detectContentType(url) {
    if (!url) return 'unknown';
    const l = url.toLowerCase();
    
    // Check exact matches first (faster)
    if (l.includes('.m3u8')) return 'hls';
    if (l.includes('.mpd')) return 'dash';
    if (l.includes('.mp4')) return 'mp4';
    if (l.includes('.webm')) return 'webm';
    if (l.includes('.flv')) return 'flv';
    if (l.includes('.mov')) return 'mov';
    if (l.includes('.ogv')) return 'ogv';
    if (l.includes('.avi')) return 'avi';
    if (l.includes('.mpg') || l.includes('.mpeg')) return 'mpeg';
    if (l.includes('.mp3')) return 'mp3';
    if (l.includes('.aac')) return 'aac';
    if (l.includes('.ogg')) return 'ogg';
    if (l.includes('.wav')) return 'wav';
    if (l.includes('.flac')) return 'flac';
    if (l.includes('.m4a')) return 'm4a';
    if (l.includes('.wma')) return 'wma';
    
    return 'unknown';
}

/**
 * @param {string} type
 * @returns {string}
 */
function getFileExtension(type) {
    /** @type {Record<string, string>} */
    const map = {
        hls: 'mp4',
        dash: 'mp4',
        mp4: 'mp4',
        webm: 'webm',
        flv: 'flv',
        mov: 'mov',
        ogv: 'ogv',
        avi: 'avi',
        mpeg: 'mpg',
        mp3: 'mp3',
        aac: 'aac',
        ogg: 'ogg',
        wav: 'wav',
        flac: 'flac',
        m4a: 'm4a',
        wma: 'wma',
        youtube: 'mp4',
        video: 'mp4',
        audio: 'mp3'
    };
    return map[type] || 'mp4';
}

/**
 * @param {string} url
 * @returns {string | null}
 */
function getCodec(url) {
    if (!url) return null;
    const lower = url.toLowerCase();
    
    // Check codec patterns (more reliable)
    if (/vp9|vp09/.test(lower)) return 'VP9';
    if (/av01/.test(lower)) return 'AV1';
    if (/h264|avc1?/.test(lower)) return 'H.264';
    if (/h265|hevc/.test(lower)) return 'H.265';
    if (/opus/.test(lower)) return 'Opus';
    if (/vorbis/.test(lower)) return 'Vorbis';
    if (/aac/.test(lower)) return 'AAC';
    if (/mp3/.test(lower)) return 'MP3';
    if (/flac/.test(lower)) return 'FLAC';
    
    return null;
}

/**
 * @param {string} url
 * @returns {string}
 */
function getVideoTitleFromUrl(url) {
    try {
        const parsedUrl = new URL(url);
        const pathname = parsedUrl.pathname;
        const filename = pathname.substring(pathname.lastIndexOf('/') + 1);
        
        // Decode and clean up query parameters
        let title = decodeURIComponent(filename);
        if (title.includes('?')) {
            title = title.split('?')[0];
        }
        
        return title || 'media';
    } catch (e) {
        return 'media';
    }
}
