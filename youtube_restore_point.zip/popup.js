// Simple, robust popup controller with virtual scrolling
class PopupUI {
    constructor() {
        /** @type {any[]} */
        this.streams = [];
        /** @type {Map<number, {progressBar: HTMLProgressElement | null, progressText: HTMLSpanElement | null}>} */
        this.downloads = new Map();
        this.virtualScroll = null;
        this.init();
    }

    init() {
        this.el = {
            loading: /** @type {HTMLElement} */ (document.getElementById('loading')),
            content: /** @type {HTMLElement} */ (document.getElementById('content')),
            empty: /** @type {HTMLElement} */ (document.getElementById('empty')),
            error: /** @type {HTMLElement} */ (document.getElementById('error')),
            errorText: /** @type {HTMLElement} */ (document.getElementById('error-text')),
            videoList: /** @type {HTMLElement} */ (document.getElementById('video-list')),
            videoCount: /** @type {HTMLElement} */ (document.getElementById('video-count')),
            refreshBtn: /** @type {HTMLButtonElement} */ (document.getElementById('refresh-btn')),
            clearBtn: /** @type {HTMLButtonElement} */ (document.getElementById('clear-btn'))
        };

        this.el.selectAll = /** @type {HTMLInputElement} */ (document.getElementById('select-all'));
        this.el.downloadSelectedBtn = /** @type {HTMLButtonElement} */ (document.getElementById('download-selected-btn'));
        this.el.copyLinksBtn = /** @type {HTMLButtonElement} */ (document.getElementById('copy-links-btn'));
        this.el.searchFilter = /** @type {HTMLInputElement} */ (document.getElementById('search-filter'));
        this.el.filtersBar = /** @type {HTMLElement} */ (document.getElementById('filters-bar'));
        this.el.filterTags = document.querySelectorAll('.filter-tag');

        this.currentFilter = 'all';
        this.searchText = '';
        this.cardsRendered = false;

        this.el.refreshBtn?.addEventListener('click', () => {
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                const tabId = tabs?.[0]?.id;
                if (tabId) {
                    this.show('loading');
                    chrome.tabs.reload(tabId, () => {
                        this.streams = [];
                        this.cardsRendered = false;
                        if (this.el.videoList) this.el.videoList.innerHTML = '';
                        
                        // Poll every 1 second, up to 10 times, to find streams
                        let attempts = 0;
                        const checkStreams = () => {
                            attempts++;
                            chrome.runtime.sendMessage({ action: 'getDetectedStreams', tabId }, (response) => {
                                if (chrome.runtime.lastError) {
                                    if (attempts < 10) setTimeout(checkStreams, 1000);
                                    else this.showError('Connection error - try reloading the page again');
                                    return;
                                }
                                
                                if (response?.streams && response.streams.length > 0) {
                                    this.streams = response.streams;
                                    this.cardsRendered = false;
                                    this.render();
                                } else if (attempts < 10) {
                                    // Keep checking
                                    setTimeout(checkStreams, 1000);
                                } else {
                                    // Give up after 10 seconds
                                    this.streams = [];
                                    this.cardsRendered = false;
                                    this.render();
                                }
                            });
                        };
                        
                        setTimeout(checkStreams, 1000);
                    });
                }
            });
        });
        
        this.el.clearBtn?.addEventListener('click', () => this.clear());
        
        this.el.selectAll?.addEventListener('change', (e) => {
            const checked = /** @type {HTMLInputElement} */ (e.target).checked;
            document.querySelectorAll('.item-checkbox').forEach((cb) => {
                const el = /** @type {HTMLInputElement} */ (cb);
                if (el.closest('.video-item')?.style.display !== 'none') {
                    el.checked = checked;
                }
            });
            this.updateDownloadBtnState();
        });

        this.el.searchFilter?.addEventListener('input', (e) => {
            this.searchText = /** @type {HTMLInputElement} */ (e.target).value.toLowerCase();
            this.render();
        });

        this.el.filterTags.forEach(tag => {
            tag.addEventListener('click', (e) => {
                this.el.filterTags.forEach(t => t.classList.remove('active'));
                const btn = /** @type {HTMLElement} */ (e.target);
                btn.classList.add('active');
                this.currentFilter = btn.dataset.type || 'all';
                this.render();
            });
        });
        
        this.el.downloadSelectedBtn?.addEventListener('click', () => this.downloadSelected());
        this.el.copyLinksBtn?.addEventListener('click', () => this.copyLinks());

        chrome.downloads.onChanged.addListener((delta) => this.updateProgress(delta));

        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            if (request.action === 'hlsProgress') {
                this.updateHlsProgress(request.streamUrl, request.progress);
            } else if (request.action === 'hlsError') {
                this.showHlsError(request.streamUrl, request.error);
            }
        });

        this.load();
    }

    /**
     * @param {string} streamUrl
     * @param {any} progress
     */
    updateHlsProgress(streamUrl, progress) {
        const stream = this.streams.find(s => s.url === streamUrl);
        if (!stream) return;
        const idx = this.streams.indexOf(stream);
        const card = this.el.videoList.querySelector(`[data-idx='${idx}']`);
        if (!card) return;
        const progressText = card.querySelector('.percentage');
        if (progressText) {
            progressText.textContent = `Downloading: ${progress.loaded}/${progress.total}`;
        }
    }

    /**
     * @param {string} streamUrl
     * @param {any} error
     */
    showHlsError(streamUrl, error) {
        const stream = this.streams.find(s => s.url === streamUrl);
        if (!stream) return;
        const idx = this.streams.indexOf(stream);
        const card = this.el.videoList.querySelector(`[data-idx='${idx}']`);
        if (!card) return;
        const progressText = card.querySelector('.percentage');
        if (progressText) {
            progressText.style.color = 'red';
            progressText.textContent = `Error: ${this.sanitize(error)}`;
        }
    }

    load() {
        this.show('loading');
        
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            const tabId = tabs?.[0]?.id;
            if (!tabId) {
                this.showError('Cannot access current tab');
                return;
            }

            chrome.runtime.sendMessage({ action: 'getDetectedStreams', tabId }, (response) => {
                if (chrome.runtime.lastError) {
                    this.showError('Connection error - reload the page');
                    return;
                }

                this.streams = response?.streams || [];
                this.cardsRendered = false;
                this.render();
            });
        });
    }

    render() {
        if (this.streams.length === 0) {
            this.show('empty');
            if (this.el.filtersBar) this.el.filtersBar.style.display = 'none';
            return;
        }

        if (this.el.filtersBar) this.el.filtersBar.style.display = 'flex';
        this.show('content');
        
        if (!this.cardsRendered) {
            this.el.videoList.innerHTML = '';
            
            // Sort so that isMain streams are at the top
            this.streams.sort((a, b) => {
                if (a.isMain && !b.isMain) return -1;
                if (!a.isMain && b.isMain) return 1;
                return 0;
            });

            const fragment = document.createDocumentFragment();
            this.streams.forEach((stream, idx) => {
                fragment.appendChild(this.createCard(stream, idx));
            });
            
            this.el.videoList.appendChild(fragment);
            this.cardsRendered = true;
            
            // Add event listeners to new checkboxes to update download button
            this.el.videoList.querySelectorAll('.item-checkbox').forEach(cb => {
                cb.addEventListener('change', () => this.updateDownloadBtnState());
            });
        }
        
        this.applyFilters();
    }
    
    applyFilters() {
        let visibleCount = 0;
        
        const cards = this.el.videoList.querySelectorAll('.video-item');
        cards.forEach((card) => {
            const idx = parseInt(/** @type {HTMLElement} */(card).dataset.idx || '0', 10);
            const stream = this.streams[idx];
            
            let isMatch = true;
            const searchTitle = (stream.title + ' ' + (stream.artist || '') + ' ' + stream.url).toLowerCase();
            
            if (this.searchText && !searchTitle.includes(this.searchText)) {
                isMatch = false;
            }
            
            if (isMatch && this.currentFilter !== 'all') {
                const streamType = (stream.type || 'unknown').toLowerCase();
                const isAudio = streamType.includes('audio') || streamType.includes('mp3') || streamType.includes('m4a') || streamType.includes('aac');
                const isVideo = streamType.includes('video') || streamType.includes('youtube');
                const isImage = streamType.includes('image');
                
                if (this.currentFilter === 'audio' && !isAudio) {
                    isMatch = false;
                } else if (this.currentFilter === 'video' && !isVideo && !(!isAudio && streamType.includes('youtube'))) {
                    isMatch = false;
                } else if (this.currentFilter === 'image' && !isImage) {
                    isMatch = false;
                } else if (this.currentFilter === 'other' && (isAudio || isVideo || isImage)) {
                    isMatch = false;
                }
            }
            
            const cardEl = /** @type {HTMLElement} */(card);
            if (isMatch) {
                cardEl.style.display = 'flex';
                visibleCount++;
            } else {
                cardEl.style.display = 'none';
                const cb = /** @type {HTMLInputElement} */(cardEl.querySelector('.item-checkbox'));
                if (cb) cb.checked = false; // Deselect if hidden
            }
        });
        
        this.el.videoCount.textContent = String(visibleCount);
        if (this.el.selectAll) this.el.selectAll.checked = false;
        this.updateDownloadBtnState();
    }
    
    updateDownloadBtnState() {
        if (!this.el.downloadSelectedBtn || !this.el.copyLinksBtn) return;
        const checkedBoxes = document.querySelectorAll('.item-checkbox:checked');
        
        if (checkedBoxes.length > 0) {
            this.el.downloadSelectedBtn.textContent = `⬇️ Download (${checkedBoxes.length})`;
            this.el.copyLinksBtn.textContent = `📋 Copy (${checkedBoxes.length})`;
        } else {
            this.el.downloadSelectedBtn.textContent = `⬇️ Download All`;
            this.el.copyLinksBtn.textContent = `📋 Copy All`;
        }
    }
    
    copyLinks() {
        let checkboxes = Array.from(document.querySelectorAll('.item-checkbox:checked'));
        if (checkboxes.length === 0) {
            // Copy all visible links if none selected
            checkboxes = Array.from(document.querySelectorAll('.item-checkbox')).filter(cb => 
                /** @type {HTMLElement} */(cb.closest('.video-item'))?.style.display !== 'none'
            );
        }
        
        const links = checkboxes.map(cb => {
            const idx = /** @type {HTMLElement} */ (cb.closest('.video-item'))?.dataset.idx || '0';
            const stream = this.streams[Number(idx)];
            
            // Try to find selected quality in dropdown, otherwise use default URL
            const card = cb.closest('.video-item');
            const select = card?.querySelector('.quality-select');
            if (select) {
                return /** @type {HTMLSelectElement} */ (select).value;
            }
            return stream.url;
        }).filter(url => url);
        
        if (links.length > 0) {
            const tempInput = document.createElement('textarea');
            tempInput.value = links.join('\n');
            document.body.appendChild(tempInput);
            tempInput.select();
            try {
                document.execCommand('copy');
                const originalText = this.el.copyLinksBtn.textContent;
                this.el.copyLinksBtn.textContent = '✅ Copied!';
                setTimeout(() => {
                    this.el.copyLinksBtn.textContent = originalText;
                }, 2000);
            } catch (e) {
                this.showError('Failed to copy links');
            }
            document.body.removeChild(tempInput);
        }
    }

    // XSS PROTECTION: Sanitize user-controlled content
    /**
     * @param {any} text
     * @returns {string}
     */
    sanitize(text) {
        const div = document.createElement('div');
        div.textContent = String(text || '').substring(0, 100);
        return div.textContent;
    }

    /**
     * @param {any} stream
     * @param {number} idx
     * @returns {HTMLElement}
     */
    createCard(stream, idx) {
        const card = document.createElement('div');
        card.className = 'video-item';
        card.dataset.idx = String(idx);

        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.className = 'item-checkbox';
        checkbox.dataset.idx = String(idx);

        const thumbnail = document.createElement('img');
        thumbnail.className = 'item-thumbnail';
        thumbnail.src = stream.thumbnail || 'icons/icon-48.png';
        thumbnail.onerror = function() {
            /** @type {HTMLImageElement} */ (this).src = 'icons/icon-48.png';
            this.onerror = null;
        };

        const details = document.createElement('div');
        details.className = 'item-details';

        const title = document.createElement('div');
        title.className = 'video-title';
        title.textContent = this.sanitize(stream.title || `Media ${idx + 1}`);
        title.title = this.sanitize(stream.title || '');

        if (stream.artist) {
            const artist = document.createElement('div');
            artist.className = 'video-artist';
            artist.textContent = this.sanitize(stream.artist);
            details.appendChild(artist);
        }

        const qualityGroup = document.createElement('div');
        qualityGroup.className = 'quality-group';

        const typeBadge = document.createElement('span');
        typeBadge.className = `video-type ${this.sanitize(stream.type)}`;
        typeBadge.textContent = String(stream.type || 'unknown').toUpperCase();

        const select = document.createElement('select');
        select.className = 'quality-select';

        if (stream.qualities?.length > 1) {
            stream.qualities.forEach(q => {
                const opt = document.createElement('option');
                opt.value = q.url || '';
                opt.textContent = this.sanitize(q.quality || 'Default');
                select.appendChild(opt);
            });
        } else {
            const opt = document.createElement('option');
            opt.value = stream.url || '';
            opt.textContent = 'Default';
            select.appendChild(opt);
        }

        qualityGroup.appendChild(typeBadge);
        qualityGroup.appendChild(select);

        const progressWrapper = document.createElement('div');
        progressWrapper.className = 'download-progress';
        progressWrapper.style.display = 'none';
        
        const progressBar = document.createElement('progress');
        progressBar.max = 100;
        progressBar.value = 0;
        
        const progressText = document.createElement('span');
        progressText.className = 'percentage';
        progressText.textContent = '';
        
        progressWrapper.appendChild(progressBar);
        progressWrapper.appendChild(progressText);
        
        details.appendChild(title);
        details.appendChild(qualityGroup);
        details.appendChild(progressWrapper);

        const btn = document.createElement('button');
        btn.className = 'download-btn';
        btn.textContent = '⬇️ DL';
        btn.onclick = () => this.download(stream, idx, select.value);

        card.appendChild(checkbox);
        card.appendChild(thumbnail);
        card.appendChild(details);
        card.appendChild(btn);

        // Quality badges
        if (stream.qualities?.length > 0) {
            const badges = document.createElement('div');
            const q = stream.qualities[0];
            if (q.quality) {
                const badge = document.createElement('span');
                badge.className = 'info-badge';
                badge.textContent = '📺 ' + this.sanitize(q.quality);
                badges.appendChild(badge);
            }
            if (stream.codec) {
                const badge = document.createElement('span');
                badge.className = 'info-badge';
                badge.textContent = '⚙️ ' + this.sanitize(stream.codec);
                badges.appendChild(badge);
            }
            if (stream.estimatedDuration) {
                const minutes = Math.floor(stream.estimatedDuration / 60);
                const badge = document.createElement('span');
                badge.className = 'info-badge';
                badge.textContent = '⏱️ ' + minutes + 'm';
                badges.appendChild(badge);
            }
            if (badges.children.length > 0) {
                card.appendChild(badges);
            }
        }

        return card;
    }

    downloadSelected() {
        let checkboxes = Array.from(document.querySelectorAll('.item-checkbox:checked'));
        
        if (checkboxes.length === 0) {
            // If none checked, assume download ALL visible
            checkboxes = Array.from(document.querySelectorAll('.item-checkbox')).filter(cb => 
                /** @type {HTMLElement} */(cb.closest('.video-item'))?.style.display !== 'none'
            );
        }
        
        if (checkboxes.length === 0) return;
        
        checkboxes.forEach((cb) => {
            const card = cb.closest('.video-item');
            if (card) {
                const idx = parseInt(/** @type {HTMLElement} */ (card).dataset.idx || '0', 10);
                const stream = this.streams[idx];
                const select = /** @type {HTMLSelectElement} */ (card.querySelector('.quality-select'));
                this.download(stream, idx, select ? select.value : stream.url);
            }
        });
    }

    /**
     * @param {any} stream
     * @param {number} idx
     * @param {string} url
     */
    download(stream, idx, url) {
        if (!url) {
            this.showError('No download URL available');
            return;
        }

        const card = this.el.videoList.querySelector(`[data-idx='${idx}']`);
        if (!card) return;

        const progressWrapper = card.querySelector('.download-progress');
        const progressText = progressWrapper?.querySelector('.percentage');

        if (url.startsWith('direct:')) {
            if (progressWrapper) progressWrapper.style.display = 'block';
            if (progressText) progressText.textContent = 'Requesting API...';
            
            const parts = url.split(':');
            const format = parts[1];
            const quality = parts[2];
            
            if (format === 'image') {
                chrome.downloads.download({
                    url: stream.thumbnail,
                    filename: `${(stream.title || 'thumbnail').replace(/[^a-zA-Z0-9._-]/g, '_')}.jpg`,
                    saveAs: false
                });
                if (progressWrapper) progressWrapper.style.display = 'none';
                return;
            }
            
            chrome.runtime.sendMessage({
                action: 'downloadDirectYouTube',
                videoUrl: stream.url,
                format: format,
                quality: quality,
                title: stream.title,
                thumbnail: stream.thumbnail
            }, (response) => {
                if (chrome.runtime.lastError || (response && response.error)) {
                    this.showError((response && response.error) || chrome.runtime.lastError.message);
                    if (progressWrapper) progressWrapper.style.display = 'none';
                } else {
                    if (progressText) progressText.textContent = 'Starting...';
                    setTimeout(() => { if (progressWrapper) progressWrapper.style.display = 'none'; }, 2000);
                }
            });
            return;
        }

        if (stream.type === 'hls') {
            if (progressWrapper) progressWrapper.style.display = 'block';
            if (progressText) progressText.textContent = 'Preparing HLS download...';
            
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                chrome.runtime.sendMessage({
                    action: 'downloadHls',
                    stream: stream,
                    tabId: tabs?.[0]?.id
                }).catch(() => {});
            });
            return;
        }

        const name = (stream.title || `video-${idx + 1}`)
            .replace(/[^a-zA-Z0-9._-]/g, '_')
            .substring(0, 50);
        const ext = getFileExtension(stream.type);
        
        if (progressWrapper) progressWrapper.style.display = 'block';

        chrome.downloads.download({
            url: url,
            filename: `${name}-${Date.now()}.${ext}`,
            saveAs: true
        }, (downloadId) => {
            if (downloadId) {
                const progressBar = progressWrapper?.querySelector('progress');
                this.downloads.set(downloadId, { progressBar, progressText });
            } else {
                if (chrome.runtime.lastError) {
                    this.showError(chrome.runtime.lastError.message);
                } else {
                    this.showError('Download failed to start');
                }
                if (progressWrapper) progressWrapper.style.display = 'none';
            }
        });
    }
    
    /**
     * @param {any} delta
     */
    updateProgress(delta) {
        if (!this.downloads.has(delta.id)) return;

        const { progressBar, progressText } = this.downloads.get(delta.id);

        if (delta.totalBytes?.current > 0 && delta.bytesReceived?.current > 0) {
            const percentage = Math.round((delta.bytesReceived.current / delta.totalBytes.current) * 100);
            if (progressBar) progressBar.value = percentage;
            if (progressText) progressText.textContent = `${percentage}%`;
        }

        if (delta.state?.current === 'complete') {
            if (progressText) progressText.textContent = 'Completed!';
            this.downloads.delete(delta.id);
        } else if (delta.state?.current === 'interrupted' || delta.state?.current === 'broken') {
            if (progressText) progressText.textContent = 'Error!';
            this.downloads.delete(delta.id);
        }
    }

    /**
     * @param {string} state
     */
    show(state) {
        if (this.el.loading) this.el.loading.style.display = state === 'loading' ? 'block' : 'none';
        if (this.el.content) this.el.content.style.display = state === 'content' ? 'block' : 'none';
        if (this.el.empty) this.el.empty.style.display = state === 'empty' ? 'block' : 'none';
        if (this.el.error) this.el.error.style.display = state === 'error' ? 'block' : 'none';
    }

    /**
     * @param {string} msg
     */
    showError(msg) {
        if (this.el.errorText) this.el.errorText.textContent = this.sanitize(msg);
        this.show('error');
    }

    clear() {
        if (confirm('Clear all videos?')) {
            this.streams = [];
            this.el.videoList.innerHTML = '';
            this.el.videoCount.textContent = '0';
            this.show('empty');
        }
    }
}

document.addEventListener('DOMContentLoaded', () => new PopupUI());
