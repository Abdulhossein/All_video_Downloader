'use strict';

// ============================================================================
// DECLARATIVE NET REQUEST RULES (For YouTube Downloads)
// ============================================================================

async function setupDnrRules() {
    try {
        await chrome.declarativeNetRequest.updateDynamicRules({
            removeRuleIds: [1],
            addRules: [{
                id: 1,
                priority: 1,
                action: {
                    type: 'modifyHeaders',
                    requestHeaders: [
                        { header: 'Referer', operation: 'set', value: 'https://www.youtube.com/' },
                        { header: 'Origin', operation: 'set', value: 'https://www.youtube.com' }
                    ]
                },
                condition: {
                    urlFilter: '||googlevideo.com',
                    resourceTypes: ['xmlhttprequest', 'sub_frame', 'main_frame', 'other']
                }
            }]
        });
        console.log('DNR rules updated');
    } catch (e) {
        console.error('Failed to update DNR rules:', e);
    }
}

// Setup on install/startup
chrome.runtime.onInstalled.addListener(() => setupDnrRules());
chrome.runtime.onStartup.addListener(() => setupDnrRules());
setupDnrRules(); // Call immediately as well

// ============================================================================
// INDEXED DB CACHE (simplified inline for MV3 compatibility)
// ============================================================================

class CacheDB {
    constructor() {
        this.db = null;
        this.ready = this.init();
    }

    async init() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open('AVDCache', 1);

            request.onerror = () => reject(request.error);
            request.onsuccess = () => {
                this.db = request.result;
                resolve(this.db);
            };

            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                if (!db.objectStoreNames.contains('m3u8Cache')) {
                    const store = db.createObjectStore('m3u8Cache', { keyPath: 'url' });
                    store.createIndex('timestamp', 'timestamp', { unique: false });
                }
                if (!db.objectStoreNames.contains('connectionSpeed')) {
                    db.createObjectStore('connectionSpeed', { keyPath: 'id' });
                }
            };
        });
    }

    async get(storeName, key) {
        await this.ready;
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(storeName, 'readonly');
            const store = transaction.objectStore(storeName);
            const request = store.get(key);
            request.onerror = () => reject(request.error);
            request.onsuccess = () => resolve(request.result);
        });
    }

    async put(storeName, value) {
        await this.ready;
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(storeName, 'readwrite');
            const store = transaction.objectStore(storeName);
            const request = store.put({ ...value, timestamp: Date.now() });
            request.onerror = () => reject(request.error);
            request.onsuccess = () => resolve(request.result);
        });
    }

    async clearOld(storeName, maxAgeMsec) {
        await this.ready;
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(storeName, 'readwrite');
            const store = transaction.objectStore(storeName);
            const index = store.index('timestamp');
            const range = IDBKeyRange.upperBound(Date.now() - maxAgeMsec);
            const request = index.openCursor(range);
            request.onerror = () => reject(request.error);
            request.onsuccess = (event) => {
                const cursor = event.target.result;
                if (cursor) {
                    cursor.delete();
                    cursor.continue();
                } else {
                    resolve();
                }
            };
        });
    }
}

const cacheDB = new CacheDB();

// ============================================================================
// LOGGING & TAB DATA (must be defined before use)
// ============================================================================

const log = (msg) => console.log('[AVD BG]', msg);

class TabDataCache {
    constructor(maxSize = 100) {
        this.data = new Map();
        this.maxSize = maxSize;
        this.accessOrder = [];
    }

    /**
     * @param {number} tabId
     * @param {any} value
     */
    set(tabId, value) {
        if (this.data.has(tabId)) {
            this.accessOrder = this.accessOrder.filter(id => id !== tabId);
        } else if (this.data.size >= this.maxSize) {
            const oldestId = this.accessOrder.shift();
            this.data.delete(oldestId);
        }
        this.data.set(tabId, value);
        this.accessOrder.push(tabId);
    }

    /**
     * @param {number} tabId
     */
    get(tabId) {
        if (this.data.has(tabId)) {
            this.accessOrder = this.accessOrder.filter(id => id !== tabId);
            this.accessOrder.push(tabId);
        }
        return this.data.get(tabId);
    }

    /**
     * @param {number} tabId
     */
    has(tabId) {
        return this.data.has(tabId);
    }

    /**
     * @param {number} tabId
     */
    delete(tabId) {
        this.accessOrder = this.accessOrder.filter(id => id !== tabId);
        return this.data.delete(tabId);
    }
}

const tabData = new TabDataCache(100);

let estimatedBandwidth = 10000000; // Default: 10 Mbps

async function measureConnectionSpeed() {
    try {
        const startTime = Date.now();
        const response = await fetch('https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png', {
            method: 'HEAD',
            cache: 'no-store'
        });
        
        if (response.ok) {
            const size = response.headers.get('content-length');
            const time = Date.now() - startTime;
            if (size && time > 0) {
                // Calculate bits per second
                estimatedBandwidth = (parseInt(size) * 8) / (time / 1000);
                log(`Connection speed: ${(estimatedBandwidth / 1000000).toFixed(2)} Mbps`);
                
                // Cache the result
                cacheDB.put('connectionSpeed', {
                    id: 'current',
                    bandwidth: estimatedBandwidth,
                    timestamp: Date.now()
                }).catch(() => {});
            }
        }
    } catch (e) {
        log('Speed measurement failed: ' + e.message);
    }
}

function selectOptimalQuality(variantPlaylists) {
    if (!variantPlaylists || variantPlaylists.length === 0) {
        return null;
    }

    // Sort by bandwidth
    const sorted = [...variantPlaylists].sort((a, b) => a.bandwidth - b.bandwidth);

    // Select quality that fits within estimated bandwidth (80% buffer)
    const targetBandwidth = estimatedBandwidth * 0.8;
    const optimal = sorted.find(v => v.bandwidth <= targetBandwidth) || sorted[0];

    log(`Adaptive bitrate: Selected ${optimal.quality} (${optimal.bandwidth} bps vs ${estimatedBandwidth} bps available)`);
    return optimal;
}

// Measure connection speed every 30 minutes
setInterval(() => measureConnectionSpeed(), 1800000);

// ============================================================================
// WEB WORKER FOR M3U8 PARSING
// ============================================================================

let m3u8Worker;

function initWorker() {
    try {
        const workerUrl = chrome.runtime.getURL('m3u8-worker.js');
        m3u8Worker = new Worker(workerUrl);
        m3u8Worker.pending = new Map();
        m3u8Worker.messageId = 0;

        m3u8Worker.onmessage = function(event) {
            const { id, success, result, error } = event.data;
            const pending = this.pending.get(id);

            if (pending) {
                if (success) {
                    pending.resolve(result);
                } else {
                    pending.reject(new Error(error));
                }
                this.pending.delete(id);
            }
        };

        log('Web Worker initialized for M3U8 parsing');
    } catch (e) {
        log('Web Worker init failed: ' + e.message);
        m3u8Worker = null;
    }
}

/**
 * @param {string} playlist
 * @param {string} playlistUrl
 */
function parseM3u8WithWorker(playlist, playlistUrl) {
    return new Promise((resolve, reject) => {
        if (!m3u8Worker) {
            // Fallback to sync parsing
            resolve(parseM3u8(playlist, playlistUrl));
            return;
        }

        const id = ++m3u8Worker.messageId;
        m3u8Worker.pending.set(id, { resolve, reject });

        m3u8Worker.postMessage({
            id,
            playlist,
            playlistUrl
        });

        // Timeout after 5s
        setTimeout(() => {
            if (m3u8Worker.pending.has(id)) {
                m3u8Worker.pending.delete(id);
                reject(new Error('M3U8 parsing timeout'));
            }
        }, 5000);
    });
}

initWorker();


function detectContentType(url) {
    if (!url) return 'unknown';
    const l = url.toLowerCase();
    if (l.includes('.m3u8')) return 'hls';
    if (l.includes('.mpd')) return 'dash';
    if (l.includes('.mp4')) return 'mp4';
    if (l.includes('.webm')) return 'webm';
    if (l.includes('.flv')) return 'flv';
    if (l.includes('.mov')) return 'mov';
    if (l.includes('.ogv')) return 'ogv';
    if (l.includes('.avi')) return 'avi';
    if (l.includes('.mpg') || l.includes('.mpeg')) return 'mpeg';
    if (l.includes('.mp3')) return 'mp3';
    if (l.includes('.aac')) return 'aac';
    if (l.includes('.ogg')) return 'ogg';
    if (l.includes('.wav')) return 'wav';
    if (l.includes('.flac')) return 'flac';
    return 'unknown';
}

function getCodec(url) {
    if (!url) return null;
    const lower = url.toLowerCase();
    if (lower.includes('vp9') || lower.includes('vp09')) return 'VP9';
    if (lower.includes('av01')) return 'AV1';
    if (lower.includes('h264') || lower.includes('avc')) return 'H.264';
    if (lower.includes('h265') || lower.includes('hevc')) return 'H.265';
    if (lower.includes('opus')) return 'Opus';
    if (lower.includes('vorbis')) return 'Vorbis';
    if (lower.includes('aac')) return 'AAC';
    if (lower.includes('mp3')) return 'MP3';
    return null;
}

function getVideoTitleFromUrl(url) {
    try {
        const parsedUrl = new URL(url);
        const pathname = parsedUrl.pathname;
        const filename = pathname.substring(pathname.lastIndexOf('/') + 1);
        return decodeURIComponent(filename) || 'media';
    } catch (e) {
        return 'media';
    }
}

function parseM3u8(playlist, playlistUrl) {
    const lines = playlist.split('\n');
    const segments = [];
    const variantPlaylists = [];

    for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();
        if (line.length === 0) continue;

        if (line.startsWith('#EXT-X-STREAM-INF')) {
            if (i + 1 < lines.length) {
                const nextLine = lines[i+1].trim();
                if (nextLine.length > 0 && !nextLine.startsWith('#')) {
                    const resolutionMatch = line.match(/RESOLUTION=(\d+x\d+)/);
                    const resolution = resolutionMatch ? resolutionMatch[1] : null;
                    let quality = 'Default';
                    if (resolution) {
                        quality = resolution.split('x')[1] + 'p';
                    }
                    variantPlaylists.push({
                        url: new URL(nextLine, playlistUrl).href,
                        info: line,
                        quality: quality
                    });
                }
            }
        } else if (!line.startsWith('#')) {
            try {
                segments.push(new URL(line, playlistUrl).href);
            } catch (e) {
                // Skip malformed URLs
            }
        }
    }
    return { segments, variantPlaylists };
}

// ============================================================================
// ADD STREAM (parse HLS and track video)
// ============================================================================

/**
 * @param {number} tabId
 * @param {any} stream
 */
async function addStream(tabId, stream) {
    if (!tabId || !stream?.url) return;

    if (!tabData.has(tabId)) {
        tabData.set(tabId, { streams: new Set() });
    }
    const data = tabData.get(tabId);

    // Parse HLS to find qualities with caching & worker
    if ((stream.type === 'hls' || stream.url.includes('.m3u8')) && !stream.qualities) {
        try {
            const cacheKey = stream.url;
            const now = Date.now();
            const CACHE_TTL = 3600000; // 1 hour

            // Try to get from IndexedDB cache first
            let cachedData = null;
            try {
                cachedData = await cacheDB.get('m3u8Cache', cacheKey);
                if (cachedData && (now - cachedData.timestamp) < CACHE_TTL) {
                    stream.qualities = cachedData.qualities;
                    stream.url = cachedData.bestUrl;
                    stream.estimatedDuration = cachedData.estimatedDuration;
                    log('M3U8 loaded from IndexedDB cache');
                    return;
                }
            } catch (e) {
                // Cache miss or error, proceed with fetch
            }

            // Fetch with 5s timeout
            const controller = new AbortController();
            const timeout = setTimeout(() => controller.abort(), 5000);
            
            const response = await fetch(stream.url, { signal: controller.signal });
            clearTimeout(timeout);
            
            const playlistText = await response.text();
            
            // Use Web Worker to parse M3U8
            const parseResult = await parseM3u8WithWorker(playlistText, stream.url);
            const { variantPlaylists, estimatedDuration } = parseResult;

            if (variantPlaylists.length > 0) {
                // Use adaptive bitrate selection
                const optimalVariant = selectOptimalQuality(variantPlaylists);
                
                stream.qualities = variantPlaylists.map(p => ({
                    quality: p.quality,
                    url: p.url,
                    bandwidth: p.bandwidth,
                    resolution: p.resolution
                }));
                stream.url = optimalVariant.url;
                stream.estimatedDuration = estimatedDuration;
                
                // Cache to IndexedDB
                try {
                    await cacheDB.put('m3u8Cache', {
                        url: cacheKey,
                        qualities: stream.qualities,
                        bestUrl: stream.url,
                        estimatedDuration,
                        timestamp: now
                    });
                } catch (e) {
                    log('Failed to cache M3U8: ' + e.message);
                }
            }
        } catch (e) {
            log('HLS parsing error: ' + e.message);
        }
    }

    // Validate stream object
    if (!stream.url || typeof stream.url !== 'string') return;

    const newStream = {
        url: stream.url,
        type: stream.type || detectContentType(stream.url),
        title: stream.title || getVideoTitleFromUrl(stream.url),
        qualities: stream.qualities || [{ quality: 'Default', url: stream.url }],
        codec: stream.codec || getCodec(stream.url),
        bitrate: stream.bitrate || null,
        estimatedDuration: stream.estimatedDuration || null,
        timestamp: Date.now()
    };

    // Deduplicate by URL or (title + type) only if it's exactly the same stream
    const existingStream = Array.from(data.streams).find(
        s => s.url === newStream.url || (s.title === newStream.title && s.type === newStream.type && s.title !== getVideoTitleFromUrl(newStream.url) && s.title !== 'Embedded Media' && s.title !== 'Video' && s.title !== 'Audio')
    );

    if (existingStream) {
        // Merge qualities if new ones found
        if (newStream.qualities.length > existingStream.qualities.length) {
            existingStream.qualities = newStream.qualities;
            existingStream.url = newStream.url;
        }
    } else {
        data.streams.add(newStream);
    }

    updateBadge(tabId, data.streams.size);
    log(`Stream found [${newStream.type}]: ${newStream.title.substring(0, 50)}`);
}
/**
 * @param {number} tabId
 * @param {number} count
 */
function updateBadge(tabId, count) {
    if (count > 0) {
        chrome.action.setBadgeText({ tabId, text: String(count) });
        chrome.action.setBadgeBackgroundColor({ tabId, color: '#667eea' });
    } else {
        chrome.action.setBadgeText({ tabId, text: '' });
    }
}

// ============================================================================
// MESSAGE LISTENER
// ============================================================================

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    try {
        const tabId = request.tabId || sender.tab?.id;

        if (request.action === 'getDetectedStreams') {
            if (!tabId) {
                sendResponse({ streams: [] });
                return;
            }
            const streams = Array.from(tabData.get(tabId)?.streams || []);
            sendResponse({ streams });
        } else if (request.action === 'trackStream') {
            if (tabId && request.stream) {
                addStream(tabId, request.stream);
            }
            sendResponse({ success: true });
        } else if (request.action === 'downloadHls') {
            if (request.stream && tabId) {
                handleHlsDownload(request.stream, tabId);
            }
            sendResponse({ success: true });
        } else if (request.action === 'getFileInfo') {
            if (request.url) {
                fetch(request.url, { method: 'HEAD' })
                    .then(res => sendResponse({
                        contentLength: res.headers.get('content-length'),
                        contentType: res.headers.get('content-type')
                    }))
                    .catch(e => sendResponse({ error: e.message }));
                return true;
            }
        } else if (request.action === 'downloadDirectYouTube') {
            handleDirectYouTube(request).then((url) => {
                 chrome.downloads.download({
                     url: url,
                     filename: `${cleanFilename(request.title)}.${request.format === 'video' ? 'mp4' : 'mp3'}`
                 });
                 sendResponse({ success: true });
            }).catch(err => {
                 sendResponse({ error: err.message });
            });
            return true;
        } else {
            sendResponse({ error: 'Unknown action' });
        }
    } catch (e) {
        log('Message error: ' + e.message);
        sendResponse({ error: e.message });
    }
});

// YOUTUBE DETECTION
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url?.includes('youtube.com')) {
        chrome.scripting.executeScript({
            target: { tabId: tabId },
            func: () => window.ytInitialPlayerResponse
        }, (results) => {
            if (chrome.runtime.lastError || !results?.[0]?.result) return;
            processYoutubeData(tabId, results[0].result);
        });
    }
});

/**
 * @param {number} tabId
 * @param {any} data
 */
function processYoutubeData(tabId, data) {
    if (!data?.videoDetails?.title) return;

    const videoTitle = data.videoDetails.title;
    const streamingData = data.streamingData;
    if (!streamingData) return;

    const formats = (streamingData.formats || []).concat(streamingData.adaptiveFormats || []);
    
    const qualities = formats
        .filter(f => f.url && f.qualityLabel)
        .map(f => ({
            quality: f.qualityLabel,
            url: f.url,
        }));

    const uniqueQualities = Array.from(new Map(qualities.map(item => [item.quality, item])).values())
        .sort((a, b) => parseInt(b.quality) - parseInt(a.quality));

    if (uniqueQualities.length > 0) {
        addStream(tabId, {
            url: uniqueQualities[0].url,
            type: 'youtube',
            title: videoTitle,
            qualities: uniqueQualities,
        });
    }
}

// DOWNLOAD RETRY WITH EXPONENTIAL BACKOFF
/**
 * @param {string} url
 * @param {number=} maxRetries
 * @param {number=} baseDelay
 */
async function fetchWithRetry(url, maxRetries = 3, baseDelay = 500) {
    let lastError;

    for (let attempt = 0; attempt <= maxRetries; attempt++) {
        try {
            const response = await fetch(url);
            if (response.ok) return response;
            
            if (response.status === 429) {
                // Rate limited - retry with backoff
                throw new Error('Rate limited');
            }
            if (response.status >= 500) {
                // Server error - retry
                throw new Error('Server error: ' + response.status);
            }
            
            return response; // Don't retry 4xx errors except 429
        } catch (error) {
            lastError = error;
            
            if (attempt < maxRetries) {
                // Exponential backoff with jitter
                const delay = baseDelay * Math.pow(2, attempt) + Math.random() * 1000;
                log(`Retry ${attempt + 1}/${maxRetries} after ${delay.toFixed(0)}ms`);
                await new Promise(resolve => setTimeout(resolve, delay));
            }
        }
    }

    throw lastError;
}

// HLS DOWNLOAD HANDLER (parallel segment downloading with retry)
/**
 * @param {any} stream
 * @param {number} tabId
 */
async function handleHlsDownload(stream, tabId) {
    try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 10000);
        
        const response = await fetchWithRetry(stream.url);
        clearTimeout(timeout);
        
        const playlistText = await response.text();
        const parseResult = await parseM3u8WithWorker(playlistText, stream.url);
        const { segments, variantPlaylists } = parseResult;

        let targetSegments = segments;

        if (segments.length === 0 && variantPlaylists.length > 0) {
            const chosenVariant = variantPlaylists[variantPlaylists.length - 1];
            const variantResponse = await fetchWithRetry(chosenVariant.url);
            const variantPlaylistText = await variantResponse.text();
            const parsedVariant = await parseM3u8WithWorker(variantPlaylistText, chosenVariant.url);
            targetSegments = parsedVariant.segments;
        }

        if (targetSegments.length === 0) {
            throw new Error('No video segments found');
        }

        // Download segments in parallel (max 6 concurrent) with retry
        const segmentArrayBuffers = [];
        const MAX_CONCURRENT = 6;
        
        for (let i = 0; i < targetSegments.length; i += MAX_CONCURRENT) {
            const batch = targetSegments.slice(i, i + MAX_CONCURRENT);
            const results = await Promise.allSettled(
                batch.map(url => fetchWithRetry(url, 3).then(r => r.arrayBuffer()))
            );
            
            results.forEach((result, idx) => {
                if (result.status === 'fulfilled') {
                    segmentArrayBuffers.push(result.value);
                } else {
                    log('Segment download failed after retries: ' + batch[idx]);
                }
            });

            // Report progress
            chrome.runtime.sendMessage({
                action: 'hlsProgress',
                streamUrl: stream.url,
                progress: { loaded: Math.min(i + MAX_CONCURRENT, targetSegments.length), total: targetSegments.length }
            }).catch(() => {});
        }

        if (segmentArrayBuffers.length === 0) {
            throw new Error('Failed to download any segments');
        }

        // Concatenate segments and create download
        const blob = new Blob(segmentArrayBuffers, { type: 'video/mp2t' });
        const blobUrl = URL.createObjectURL(blob);

        const filename = (stream.title.replace(/[^a-zA-Z0-9._-]/g, '_') || 'video') + '.ts';

        chrome.downloads.download({
            url: blobUrl,
            filename: filename
        }, (downloadId) => {
            const onDownloadChanged = (delta) => {
                if (delta.id === downloadId && delta.state?.current !== 'in_progress') {
                    URL.revokeObjectURL(blobUrl);
                    chrome.downloads.onChanged.removeListener(onDownloadChanged);
                }
            };
            chrome.downloads.onChanged.addListener(onDownloadChanged);
        });
    } catch (e) {
        log('HLS download failed: ' + e.message);
        chrome.runtime.sendMessage({
            action: 'hlsError',
            streamUrl: stream.url,
            error: e.message
        }).catch(() => {});
    }
}

// CLEANUP: Remove tab data when tab is closed
chrome.tabs.onRemoved.addListener((tabId) => {
    if (tabData.has(tabId)) {
        tabData.delete(tabId);
        log('Cleaned up tab data for ' + tabId);
    }
});

// Cleanup stale IndexedDB cache entries every 30 minutes
setInterval(() => {
    cacheDB.clearOld('m3u8Cache', 3600000).then(() => {
        log('Cleaned up stale M3U8 cache');
    }).catch(e => log('Cache cleanup error: ' + e.message));
}, 1800000);

log('Background service worker initialized');

// ============================================================================
// YOUTUBE DIRECT API
// ============================================================================
let cachedConverterServers = null;
let lastServerFetchTime = 0;

async function getConverterServers() {
    const defaultServers = [
        { name: "y2meta-uk", origin: "https://iframe.y2meta-uk.com", referer: "https://iframe.y2meta-uk.com/" },
        { name: "mp3yt", origin: "https://mp3yt.is", referer: "https://mp3yt.is/" },
    ];
    
    // Cache for 24 hours
    if (cachedConverterServers && (Date.now() - lastServerFetchTime < 24 * 60 * 60 * 1000)) {
        return cachedConverterServers;
    }
    
    try {
        // Auto-update proxy servers from the GreasyFork script
        const response = await fetch('https://update.greasyfork.org/scripts/527945/YouTube%20Direct%20Downloader.user.js');
        const text = await response.text();
        
        // Regex to extract CONVERTER_SERVERS array from the source code
        const match = text.match(/const\s+CONVERTER_SERVERS\s*=\s*(\[[\s\S]*?\]);/);
        if (match && match[1]) {
            // Convert JS object syntax to valid JSON
            let jsonStr = match[1]
                .replace(/([a-zA-Z0-9_]+)\s*:/g, '"$1":') // Quote keys
                .replace(/'/g, '"') // Replace single quotes with double
                .replace(/,\s*([\]}])/g, '$1'); // Remove trailing commas
            
            const servers = JSON.parse(jsonStr);
            if (servers && servers.length > 0) {
                cachedConverterServers = servers;
                lastServerFetchTime = Date.now();
                log('Updated converter servers from GreasyFork');
                return servers;
            }
        }
    } catch (e) {
        log('Failed to fetch updated servers from GreasyFork: ' + e.message);
    }
    
    return defaultServers;
}

async function handleDirectYouTube(request) {
    const CONVERTER_API_BASE = "https://cnv.cx";
    const servers = await getConverterServers();
    
    let payload;
    if (request.format === "video") {
        payload = new URLSearchParams({
            link: request.videoUrl,
            format: "mp4",
            audioBitrate: "128",
            videoQuality: request.quality,
            filenameStyle: "pretty",
            vCodec: "h264",
        });
    } else {
        payload = new URLSearchParams({
            link: request.videoUrl,
            format: "mp3",
            audioBitrate: request.quality,
            filenameStyle: "pretty",
        });
    }

    let lastError = null;
    for (const server of servers) {
        try {
            // 1. Get Key
            const keyRes = await fetch(`${CONVERTER_API_BASE}/v2/sanity/key`, {
                headers: { "Origin": server.origin, "Referer": server.referer }
            });
            const keyData = await keyRes.json();
            if (!keyData?.key) throw new Error("Failed to get API key");
            
            // 2. Convert
            const convertRes = await fetch(`${CONVERTER_API_BASE}/v2/converter`, {
                method: 'POST',
                headers: { 
                    "Origin": server.origin, 
                    "Referer": server.referer, 
                    "Content-Type": "application/x-www-form-urlencoded",
                    "key": keyData.key
                },
                body: payload
            });
            
            const result = await convertRes.json();
            if (result?.url) return result.url;
            throw new Error(`No download URL received (${result?.error?.code || result?.status || 'unknown error'})`);
        } catch (e) {
            lastError = e;
            log(`Server ${server.name} failed: ${e.message}`);
        }
    }
    
    throw lastError || new Error("All converter servers failed");
}

function cleanFilename(filename) {
    if (!filename) return "YouTube_Video";
    return filename.replace(/[<>:"/\\|?*]/g, "").replace(/[\u0000-\u001f\u007f-\u009f]/g, "").replace(/^\.+/, "").replace(/\.+$/, "").replace(/\s+/g, " ").trim() || "YouTube_Video";
}
