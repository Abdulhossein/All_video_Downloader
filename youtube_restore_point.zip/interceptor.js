// Runs in the MAIN world to intercept network requests (bypasses CSP on some sites and exposes window.fetch)
(function() {
    // Prevent multiple injections
    if (window._avdInterceptorInjected) return;
    window._avdInterceptorInjected = true;

    // Helper to send ytInitialPlayerResponse data
    let sentStreamingData = false;
    function trySendStreamingData() {
        if (sentStreamingData) return;
        try {
            const data = window.ytInitialPlayerResponse?.streamingData;
            if (data) {
                window.postMessage({ type: 'AVD_YOUTUBE_STREAMING_DATA', data: JSON.stringify(data) }, '*');
                sentStreamingData = true;
            }
        } catch (e) {}
    }

    const originalFetch = window.fetch;
    window.fetch = async function(...args) {
        trySendStreamingData();
        const url = typeof args[0] === 'string' ? args[0] : args[0]?.url;
        if (url && typeof url === 'string' && url.includes('googlevideo.com/videoplayback')) {
            window.postMessage({ type: 'AVD_INTERCEPTED_URL', url: url }, '*');
        }
        return originalFetch.apply(this, args);
    };

    const originalXHR = window.XMLHttpRequest.prototype.open;
    window.XMLHttpRequest.prototype.open = function(method, url, ...rest) {
        trySendStreamingData();
        if (typeof url === 'string' && url.includes('googlevideo.com/videoplayback')) {
            window.postMessage({ type: 'AVD_INTERCEPTED_URL', url: url }, '*');
        }
        return originalXHR.call(this, method, url, ...rest);
    };
})();
