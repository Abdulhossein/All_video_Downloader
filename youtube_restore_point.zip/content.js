// Enhanced content script - comprehensive media detection
'use strict';

const log = (msg) => console.log(`[AVD Content]`, msg);

// Use regular Set instead of WeakSet (WeakSet doesn't work well for tracking)
const processedElements = new Set();
/** @type {Set<string>} */
const sentUrls = new Set(); // Max 50K URLs to prevent memory leak

// Cleanup old entries from sentUrls periodically (prevent unbounded growth)
setInterval(() => {
    if (sentUrls.size > 40000) {
        const arr = Array.from(sentUrls);
        processedElements.clear();
        sentUrls.clear();
        // Keep only recent 10K
        arr.slice(-10000).forEach(url => sentUrls.add(url));
        log('Cleaned up URL cache. Size: ' + sentUrls.size);
    }
}, 60000); // Every minute

// ============================================================================
// NETWORK INTERCEPTION (Bypasses deciphering/DRM by catching actual requests)
// ============================================================================
function injectNetworkInterceptor() {
    // Only inject on YouTube for now to prevent breaking other sites unnecessarily
    if (!window.location.hostname.includes('youtube.com')) return;

    const script = document.createElement('script');
    script.src = chrome.runtime.getURL('interceptor.js');
    (document.head || document.documentElement).appendChild(script);
    
    script.onload = () => {
        script.remove();
    };

    window.addEventListener('message', (event) => {
        if (event.source !== window || !event.data) return;
        
        if (event.data.type === 'AVD_YOUTUBE_STREAMING_DATA') {
            try {
                window._ytStreamingData = JSON.parse(event.data.data);
            } catch(e) {}
            return;
        }

        if (event.data.type !== 'AVD_INTERCEPTED_URL') return;
        
        try {
            const urlObj = new URL(event.data.url);
            // Remove chunk-specific params to get the full file URL
            urlObj.searchParams.delete('range');
            urlObj.searchParams.delete('rn');
            urlObj.searchParams.delete('rbuf');
            
            const cleanUrl = urlObj.toString();
            if (sentUrls.has(cleanUrl)) return;
            sentUrls.add(cleanUrl);

            const sendFinalStream = (quality, isAudioOverride = false) => {
                const title = document.title.replace(/^\\([0-9]+\\)\\s*/, ''); // Remove notification count
                chrome.runtime.sendMessage({
                    action: 'trackStream',
                    stream: {
                        url: cleanUrl,
                        type: isAudioOverride ? 'audio' : 'youtube',
                        title: title,
                        qualities: [{ quality: quality, url: cleanUrl }]
                    }
                }).catch(e => {});
            };

            const mime = urlObj.searchParams.get('mime') || '';
            const isAudio = mime.includes('audio');
            const itag = urlObj.searchParams.get('itag');

            if (itag) {
                let quality = `Itag ${itag}`;
                if (itag === '18') quality = '360p (Muxed)';
                else if (itag === '22') quality = '720p (Muxed)';
                else if (isAudio) quality = 'Audio Only';
                else quality = `Video Only (${quality})`;
                sendFinalStream(quality, isAudio);
            } else {
                // If no itag is present, do a HEAD request via background to match contentLength
                chrome.runtime.sendMessage({ action: 'getFileInfo', url: cleanUrl }, (response) => {
                    let finalQuality = 'Default';
                    let isAudioFinal = isAudio;
                    
                    if (response && response.contentLength && window._ytStreamingData) {
                        const len = response.contentLength;
                        const formats = [
                            ...(window._ytStreamingData.formats || []),
                            ...(window._ytStreamingData.adaptiveFormats || [])
                        ];
                        
                        const format = formats.find(f => f.contentLength == len);
                        if (format) {
                            let q = format.qualityLabel || 'Unknown';
                            const fMime = format.mimeType || '';
                            const fIsAudio = fMime.includes('audio');
                            
                            if (fIsAudio && !fMime.includes('video')) {
                                const aq = format.audioQuality ? format.audioQuality.replace('AUDIO_QUALITY_', '') : 'Unknown';
                                q = `Audio Only (${aq})`;
                                isAudioFinal = true;
                            } else if (fMime.includes('video') && !fIsAudio) {
                                q = `Video Only (${q})`;
                            } else {
                                q = `${q} (Muxed)`;
                            }
                            finalQuality = q;
                        }
                    } else if (response && response.contentType) {
                        if (response.contentType.includes('audio')) {
                            finalQuality = 'Audio Only';
                            isAudioFinal = true;
                        } else {
                            finalQuality = 'Video Only';
                        }
                    }
                    sendFinalStream(finalQuality, isAudioFinal);
                });
            }
        } catch (e) {}
    });
}
injectNetworkInterceptor();

// ============================================================================
// YOUTUBE DIRECT API INTEGRATION
// ============================================================================
function injectYouTubeDirectStream() {
    if (window.location.hostname.includes('youtube.com') && window.location.pathname.startsWith('/watch')) {
        const urlObj = new URL(window.location.href);
        const videoId = urlObj.searchParams.get('v');
        if (videoId && !sentUrls.has('yt_direct_' + videoId)) {
            sentUrls.add('yt_direct_' + videoId);
            
            // Wait a bit for title to load
            setTimeout(() => {
                let title = document.title.replace(/^\(\d+\)\s*/, "").replace(" - YouTube", "").trim();
                if (!title || title === "YouTube") {
                    const titleEl = document.querySelector('h1.ytd-watch-metadata #title, h1 yt-formatted-string');
                    if (titleEl) title = titleEl.textContent.trim();
                }
                if (!title) title = "YouTube_Video";

                const thumbnailUrl = `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`;
                
                const stream = {
                    url: window.location.href, // Use watch URL as identifier
                    type: 'youtube', // Use 'youtube' to get the nice styling in popup
                    title: title,
                    thumbnail: thumbnailUrl,
                    isMain: true,
                    qualities: [
                        { quality: '1080p (MP4)', url: 'direct:video:1080', type: 'video' },
                        { quality: '720p (MP4)', url: 'direct:video:720', type: 'video' },
                        { quality: '360p (MP4)', url: 'direct:video:360', type: 'video' },
                        { quality: '320kbps (MP3)', url: 'direct:audio:320', type: 'audio' },
                        { quality: 'Thumbnail (JPG)', url: 'direct:image:thumb', type: 'image' }
                    ]
                };
                chrome.runtime.sendMessage({ action: 'trackStream', stream }).catch(e => {});
            }, 1500);
        }
    }
}
injectYouTubeDirectStream();
// Handle YouTube SPA navigation
window.addEventListener("yt-navigate-finish", injectYouTubeDirectStream);

/**
 * Helper to query elements deeply, including those hidden inside Shadow DOMs
 * @param {string} selector 
 * @param {Element|Document} root 
 * @returns {Element[]}
 */
function querySelectorAllDeep(selector, root) {
    const results = [];
    const visited = new Set();
    
    function traverse(node) {
        if (!node || visited.has(node)) return;
        visited.add(node);

        if (node.querySelectorAll) {
            node.querySelectorAll(selector).forEach(el => results.push(el));
        }
        
        const elements = node.querySelectorAll ? node.querySelectorAll('*') : [];
        elements.forEach(el => {
            if (el.shadowRoot) {
                traverse(el.shadowRoot);
            }
        });
        
        if (node.shadowRoot) {
            traverse(node.shadowRoot);
        }
    }
    
    traverse(root);
    return Array.from(new Set(results));
}

/**
 * @param {Element|HTMLElement|Document} node
 */
function findMedia(node) {
    if (!node) return;

    // Find <video> and <audio> tags (including inside Shadow DOM)
    try {
        querySelectorAllDeep('video, audio', node).forEach(mediaElement => {
            const elId = Math.random(); // Simple tracking instead of WeakSet
            if (processedElements.has(elId)) return;
            processedElements.add(elId);

            const handleSrc = () => {
                const src = mediaElement.currentSrc || mediaElement.src;
                if (src && !src.startsWith('blob:') && !sentUrls.has(src)) {
                    sentUrls.add(src);
                    const stream = {
                        url: src,
                        title: getTitle(mediaElement)
                    };
                    augmentRadioJavanStream(stream);
                    chrome.runtime.sendMessage({ action: 'trackStream', stream }).catch(e => {});
                }
            };

            // Extract from standard sources immediately
            if (mediaElement.currentSrc || mediaElement.src) {
                handleSrc();
            }

            // Extract from <source> tags
            mediaElement.querySelectorAll('source').forEach(source => {
                if (source.src && !source.src.startsWith('blob:') && !sentUrls.has(source.src)) {
                    sentUrls.add(source.src);
                    const stream = { url: source.src, title: getTitle(mediaElement) };
                    augmentRadioJavanStream(stream);
                    chrome.runtime.sendMessage({
                        action: 'trackStream',
                        stream: stream
                    }).catch(e => {});
                }
            });

            // Extract from lazy-load data attributes
            const dataSrc = mediaElement.getAttribute('data-src') || mediaElement.getAttribute('data-video-url') || mediaElement.getAttribute('data-audio-url');
            if (dataSrc && !sentUrls.has(dataSrc) && dataSrc.startsWith('http')) {
                sentUrls.add(dataSrc);
                chrome.runtime.sendMessage({
                    action: 'trackStream',
                    stream: { url: dataSrc, title: getTitle(mediaElement) }
                }).catch(e => {});
            }

            // Fallback for dynamically loaded streams
            mediaElement.addEventListener('canplay', handleSrc, { once: true });
            mediaElement.addEventListener('loadedmetadata', handleSrc, { once: true });
        });
    } catch (e) {
        // Ignore errors in querySelector
    }

    // Find links to media files
    try {
        node.querySelectorAll('a[href]').forEach(anchor => {
            if (!anchor.href) return;
            
            const href = anchor.href;
            const type = detectContentType(href);

            if (type !== 'unknown' && !sentUrls.has(href)) {
                sentUrls.add(href);
                const stream = {
                    url: href,
                    title: anchor.title || anchor.textContent.trim() || getVideoTitleFromUrl(href)
                };
                chrome.runtime.sendMessage({ action: 'trackStream', stream }).catch(e => {});
            }
        });
    } catch (e) {
        // Ignore errors
    }
}

/**
 * @param {Element} el
 * @returns {string}
 */
function getTitle(el) {
    try {
        // Try to find a title from surrounding elements
        const parent = el.closest('div, article, main, section');
        if (parent) {
            const h = parent.querySelector('h1, h2, h3, [class*="title"], [id*="title"]');
            if (h && h.textContent.trim()) {
                return h.textContent.trim().substring(0, 150);
            }
        }
        // Fallback to page title or URL
        return document.title || 'Video';
    } catch (e) {
        return 'Video';
    }
}

// ============================================================================
// RADIOJAVAN METADATA EXTRACTION
// ============================================================================
function augmentRadioJavanStream(stream) {
    if (!window.location.hostname.includes('radiojavan.com')) return;
    
    // RJ media URLs typically look like: https://host1.rj-mw1.com/media/...
    // If it's the main media element, we attach the page metadata.
    // We assume any video/audio on the song/video page is the main media.
    try {
        const ogTitle = document.querySelector('meta[property="og:title"]')?.content || '';
        const ogImage = document.querySelector('meta[property="og:image"]')?.content || '';
        const ogDesc = document.querySelector('meta[property="og:description"]')?.content || '';
        
        if (ogTitle) {
            // "Vatan - Single by Sami Low & Saade"
            let title = ogTitle;
            let artist = '';
            
            if (ogTitle.includes(' by ')) {
                const parts = ogTitle.split(' by ');
                title = parts[0].replace(' - Single', '').trim();
                artist = parts[1].trim();
            } else if (ogTitle.includes(' - ')) {
                const parts = ogTitle.split(' - ');
                artist = parts[0].trim();
                title = parts.slice(1).join(' - ').trim();
            }
            
            stream.title = title;
            stream.artist = artist;
            if (ogImage) stream.thumbnail = ogImage;
            
            // Extract the info string (Song - 3 mins 42 secs - Jul 20, 2026)
            // It's usually in a <p> tag with text like "Song - " or "Video - "
            const pTags = Array.from(document.querySelectorAll('p'));
            const infoTag = pTags.find(p => p.textContent.includes(' - ') && (p.textContent.includes('Song') || p.textContent.includes('Video') || p.textContent.includes('Podcast')));
            
            if (infoTag) {
                // If artist exists, append this to artist, or add it as a separate field
                if (stream.artist) {
                    stream.artist += ' | ' + infoTag.textContent.trim();
                } else {
                    stream.artist = infoTag.textContent.trim();
                }
            } else if (ogDesc) {
                // Fallback to og:description which has similar info
                stream.artist += ' | ' + ogDesc.replace(/[^a-zA-Z0-9\s:,-]/g, '-');
            }
            
            // Mark as main video so popup can sort it to the top
            stream.isMain = true;
        }
    } catch (e) {}
}

/**
 * Try to extract advanced media info from JSON blobs (Next.js, generic JSON, RadioJavan)
 */
function extractAdvancedMediaInfo() {
    try {
        // 1. Next.js Data (used by many modern sites like RadioJavan)
        const nextDataElement = document.getElementById('__NEXT_DATA__');
        if (nextDataElement && nextDataElement.textContent) {
            try {
                const jsonData = JSON.parse(nextDataElement.textContent);
                const props = jsonData.props?.pageProps || {};
                const media = props.media || props.podcast || props.video || props.track || props.song;
                
                if (media) {
                    const url = media.hq_link || media.hd_4k_link || media.high || media.lq_link || media.low || media.url || media.file;
                    if (url && !sentUrls.has(url)) {
                        sentUrls.add(url);
                        chrome.runtime.sendMessage({
                            action: 'trackStream',
                            stream: {
                                url: url,
                                title: media.song || media.title || media.name || document.title,
                                artist: media.artist || media.podcast_artist || '',
                                thumbnail: media.photo || media.coverPhoto || media.thumbnail || media.image || ''
                            }
                        }).catch(e => {});
                    }
                }
            } catch (e) {}
        }

        // 2. RadioJavan specific older format
        for (const script of document.querySelectorAll('script')) {
            if (script.textContent && (script.textContent.includes('RJ.currentMP3') || script.textContent.includes('RJ.currentVideo'))) {
                const match = script.textContent.match(/RJ\.current(?:MP3|Video)\s*=\s*({.*?});/s);
                if (match) {
                    try {
                        const media = JSON.parse(match[1]);
                        const url = media.hq_link || media.lq_link;
                        if (url && !sentUrls.has(url)) {
                            sentUrls.add(url);
                            chrome.runtime.sendMessage({
                                action: 'trackStream',
                                stream: {
                                    url: url,
                                    title: media.song || media.title || document.title,
                                    artist: media.artist || '',
                                    thumbnail: media.photo || media.thumbnail || ''
                                }
                            }).catch(e => {});
                        }
                    } catch (e) {}
                }
            }
        }
    } catch (e) {
        log('Error in advanced media extraction: ' + e.message);
    }
}

/**
 * Perform a deep scan of all script tags to find hidden media URLs (JSON, initial state, etc.)
 * Useful for SPAs where video objects are loaded but not yet inserted into the DOM.
 */
function scanScriptsForMedia() {
    extractAdvancedMediaInfo();
    try {
        const scripts = document.querySelectorAll('script:not([src])');
        // Comprehensive regex to find media URLs, accounting for escaped slashes (\/)
        // Matches: http://.../file.mp4 or https:\/\/...\/file.m3u8
        const urlRegex = /(?:https?:(?:\\?\/){2})[^\s"'<>]+?\.(?:mp4|m3u8|mp3|webm|m4a|aac|flv|wav|ogg|flac|wma)(?:[?&#][^\s"'<>]+)?/gi;
        
        // Try to find a global generic thumbnail in meta tags
        const ogImage = document.querySelector('meta[property="og:image"]')?.getAttribute('content') || '';
        
        scripts.forEach(script => {
            if (!script.textContent) return;
            const text = script.textContent;
            const matches = text.match(urlRegex);
            if (matches) {
                matches.forEach(match => {
                    // Unescape slashes if they were escaped in JSON string
                    const cleanUrl = match.replace(/\\\//g, '/');
                    if (!sentUrls.has(cleanUrl)) {
                        sentUrls.add(cleanUrl);
                        
                        // Heuristic: Try to find "title" or "name" or "thumbnail" near this URL in the JSON string
                        // We just take a window of 500 chars around the URL to guess title
                        const urlIndex = text.indexOf(match);
                        const windowText = text.substring(Math.max(0, urlIndex - 500), Math.min(text.length, urlIndex + 500));
                        
                        let title = getVideoTitleFromUrl(cleanUrl) || document.title || 'Embedded Media';
                        let thumbnail = ogImage;
                        let artist = '';
                        
                        // Simple regex to find "title":"something" or "name":"something"
                        const titleMatch = windowText.match(/["'](?:title|name|song)["']\s*:\s*["']([^"'\\]+)["']/i);
                        if (titleMatch && titleMatch[1]) {
                            title = titleMatch[1];
                        }
                        
                        const artistMatch = windowText.match(/["'](?:artist|author)["']\s*:\s*["']([^"'\\]+)["']/i);
                        if (artistMatch && artistMatch[1]) {
                            artist = artistMatch[1];
                        }
                        
                        const thumbMatch = windowText.match(/["'](?:thumbnail|cover|image|photo)["']\s*:\s*["'](https?[^"'\\]+)["']/i);
                        if (thumbMatch && thumbMatch[1]) {
                            thumbnail = thumbMatch[1].replace(/\\\//g, '/');
                        }
                        
                        chrome.runtime.sendMessage({
                            action: 'trackStream',
                            stream: {
                                url: cleanUrl,
                                title: title,
                                artist: artist,
                                thumbnail: thumbnail
                            }
                        }).catch(e => {});
                    }
                });
            }
        });
    } catch (e) {
        log('Error scanning scripts: ' + e.message);
    }
}

// MutationObserver with debounce to avoid excessive processing
let mutationTimeout;
const observer = new MutationObserver((mutations) => {
    clearTimeout(mutationTimeout);
    mutationTimeout = setTimeout(() => {
        let shouldScanScripts = false;
        for (const mutation of mutations) {
            if (mutation.addedNodes.length) {
                for (const node of mutation.addedNodes) {
                    if (node.nodeType === 1) { // ELEMENT_NODE
                        findMedia(node);
                        if (node.tagName === 'SCRIPT' || node.querySelector('script')) {
                            shouldScanScripts = true;
                        }
                    }
                }
            }
        }
        if (shouldScanScripts) {
            scanScriptsForMedia();
        }
    }, 500); // Debounce 500ms instead of immediate
});

// Only observe main document, not all frames
observer.observe(document.documentElement, {
    childList: true,
    subtree: true
});

// Initial scan - wait for DOM to settle
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        setTimeout(() => {
            findMedia(document.body || document.documentElement);
            scanScriptsForMedia();
        }, 500);
    });
} else {
    setTimeout(() => {
        findMedia(document.body || document.documentElement);
        scanScriptsForMedia();
    }, 500);
}

log('Initialized');

