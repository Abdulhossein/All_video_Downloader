# All Video Downloader

This Chrome extension allows you to download videos from various websites.

## How to use

1.  Load the extension in Chrome in developer mode.
2.  Navigate to a website with a video you want to download.
3.  Play the video.
4.  Click on the extension icon to see the list of detected videos.
5.  Click the "DL" button to download the video.

## Improvements in this version

*   **More Robust Media Detection:** The extension now uses multiple techniques to find media, including searching for `<video>` and `<audio>` tags, intercepting network requests, and specific logic for YouTube.
*   **Wider Range of Supported Sites:** The ability to detect media in iframes has been added.
*   **Broader Media Type Support:** The extension can now detect more types of video and audio files.
*   **Improved Code Quality:** The code has been refactored to be more modular, maintainable, and efficient.
